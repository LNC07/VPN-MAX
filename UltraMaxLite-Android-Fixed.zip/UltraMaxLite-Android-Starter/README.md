# UltraMax Lite — Android Starter (Fixed)

- Kotlin plugin **1.9.24**
- Material3 theme fixed (`Theme.Material3.DayNight`)
- Compose compiler ext 1.5.14
- Ready for GitHub Actions with Gradle **8.7** (via workflow)

Build with your workflow steps:
1) unzip `UltraMaxLite-Android-Fixed.zip`
2) `gradle wrapper --gradle-version 8.7`
3) `./gradlew assembleDebug`
