package com.ultramaxlite.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.ultramaxlite.vpn.MainActivity
import com.ultramaxlite.vpn.R
import kotlinx.coroutines.*

class UltraMaxVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.ultramaxlite.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.ultramaxlite.vpn.DISCONNECT"
        private const val NOTIF_CHANNEL_ID = "ultramax_vpn"
        private const val NOTIF_ID = 1001
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var scope: CoroutineScope? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> startVpn()
            ACTION_DISCONNECT -> stopVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        if (scope != null) return
        startForeground(NOTIF_ID, buildNotification("Connecting…"))
        scope = CoroutineScope(Dispatchers.IO)
        scope?.launch {
            // Placeholder: establish TUN; WireGuard engine integration pending
            val builder = Builder()
                .setSession("UltraMax Lite")
                .addAddress("10.8.0.10", 32)
                .addDnsServer("1.1.1.1")
                .allowFamily(android.system.OsConstants.AF_INET)

            vpnInterface = builder.establish()

            withContext(Dispatchers.Main) {
                updateNotification("Ready — add WG engine to route traffic")
            }
        }
    }

    private fun stopVpn() {
        scope?.cancel()
        scope = null
        vpnInterface?.close()
        vpnInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(NOTIF_CHANNEL_ID, "UltraMax VPN", NotificationManager.IMPORTANCE_LOW)
            mgr.createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_ultramax)
            .setContentTitle("UltraMax Lite")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        mgr.notify(NOTIF_ID, buildNotification(text))
    }
}
