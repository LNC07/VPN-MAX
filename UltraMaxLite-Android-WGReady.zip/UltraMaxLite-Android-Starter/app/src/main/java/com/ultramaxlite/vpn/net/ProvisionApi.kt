package com.ultramaxlite.vpn.net

import retrofit2.http.Body
import retrofit2.http.POST

data class PeerRequest(val client_pubkey: String)
data class PeerResponse(
    val address: String,
    val server_public_key: String,
    val endpoint: String,
    val dns: String,
    val keepalive: Int
)

interface ProvisionApi {
    @POST("api/peer")
    suspend fun createPeer(@Body body: PeerRequest): PeerResponse
}
