package com.ultramaxlite.vpn

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultramaxlite.vpn.vpn.UltraMaxVpnService

class MainActivity : ComponentActivity() {

    private val prepareVpn = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        // Result OK -> user approved
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HomeScreen(
                        onConnect = { requestVpnPermissionAndStart(true) },
                        onDisconnect = { requestVpnPermissionAndStart(false) }
                    )
                }
            }
        }
    }

    private fun requestVpnPermissionAndStart(connect: Boolean) {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            prepareVpn.launch(intent)
        } else {
            // Already prepared
            toggleVpn(connect)
        }
    }

    private fun toggleVpn(connect: Boolean) {
        val intent = Intent(this, UltraMaxVpnService::class.java).apply {
            action = if (connect) UltraMaxVpnService.ACTION_CONNECT else UltraMaxVpnService.ACTION_DISCONNECT
        }
        startService(intent)
    }
}

@Composable
fun HomeScreen(onConnect: () -> Unit, onDisconnect: () -> Unit) {
    var status by remember { mutableStateOf("Disconnected") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("UltraMax Lite", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Fast. Light. Private.")
        Spacer(Modifier.height(32.dp))
        Row {
            Button(onClick = {
                onConnect()
                status = "Connecting…"
            }) { Text("Connect") }
            Spacer(Modifier.width(20.dp))
            OutlinedButton(onClick = {
                onDisconnect()
                status = "Disconnecting…"
            }) { Text("Disconnect") }
        }
        Spacer(Modifier.height(24.dp))
        Text("Status: " + status)
    }
}
