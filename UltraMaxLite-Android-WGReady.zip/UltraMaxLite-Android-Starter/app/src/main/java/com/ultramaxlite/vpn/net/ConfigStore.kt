package com.ultramaxlite.vpn.net

import android.content.Context
import java.io.File

object ConfigStore {
    private const val FILE_NAME = "wg_config.conf"
    fun save(context: Context, content: String) {
        val f = File(context.filesDir, FILE_NAME)
        f.writeText(content)
    }
    fun load(context: Context): String? {
        val f = File(context.filesDir, FILE_NAME)
        return if (f.exists()) f.readText() else null
    }
}