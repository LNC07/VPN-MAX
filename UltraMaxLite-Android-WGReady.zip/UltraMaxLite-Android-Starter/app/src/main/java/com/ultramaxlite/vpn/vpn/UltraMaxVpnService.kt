package com.ultramaxlite.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.ultramaxlite.vpn.MainActivity
import com.ultramaxlite.vpn.R
import com.ultramaxlite.vpn.crypto.X25519Util
import com.ultramaxlite.vpn.net.ApiClient
import com.ultramaxlite.vpn.net.ConfigStore
import com.ultramaxlite.vpn.net.PeerRequest
import com.ultramaxlite.vpn.net.ProvisionApi
import kotlinx.coroutines.*
import retrofit2.create

class UltraMaxVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.ultramaxlite.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.ultramaxlite.vpn.DISCONNECT"
        private const val NOTIF_CHANNEL_ID = "ultramax_vpn"
        private const val NOTIF_ID = 1001
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var scope: CoroutineScope? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> startVpn()
            ACTION_DISCONNECT -> stopVpn()
        }
        return START_STICKY
    }

    private fun startVpn() {
        if (scope != null) return
        startForeground(NOTIF_ID, buildNotification("Connecting…"))
        scope = CoroutineScope(Dispatchers.IO)
        scope?.launch {
            try {
                // 1) Generate X25519 keypair (base64-encoded DER keys)
                val kp = X25519Util.generate()

                // 2) Request peer config from Provisioning API
                val api = ApiClient.retrofit.create<ProvisionApi>()
                val resp = api.createPeer(PeerRequest(client_pubkey = kp.publicKey))

                // 3) Build WireGuard config text (to be applied by WG engine)
                val configText = """
                    [Interface]
                    PrivateKey = ${'$'}{kp.privateKey}
                    Address = ${'$'}{resp.address}
                    DNS = ${'$'}{resp.dns}

                    [Peer]
                    PublicKey = ${'$'}{resp.server_public_key}
                    Endpoint = ${'$'}{resp.endpoint}
                    AllowedIPs = 0.0.0.0/0, ::/0
                    PersistentKeepalive = ${'$'}{resp.keepalive}
                """.trimIndent()

                // 4) Save locally for debugging / future use
                ConfigStore.save(this@UltraMaxVpnService, configText)

                // 5) Establish TUN (system side). WG engine should take this FD and route packets.
                val address = resp.address.substringBefore("/")
                val prefix = resp.address.substringAfter("/").toInt()
                val builder = Builder()
                    .setSession("UltraMax Lite")
                    .addAddress(address, prefix)
                    .addDnsServer(resp.dns)
                    .allowFamily(android.system.OsConstants.AF_INET)

                vpnInterface = builder.establish()

                // 6) TODO: Apply the config to an embedded WireGuard engine and bind to vpnInterface FD.
                // Without the WG engine, traffic won't flow yet. This service completes all pre-requisites.

                withContext(Dispatchers.Main) { updateNotification("Ready — add WG engine to route traffic") }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { updateNotification("Error: ${e.message}") }
            }
        }
    }

    private fun stopVpn() {
        scope?.cancel()
        scope = null
        vpnInterface?.close()
        vpnInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(NOTIF_CHANNEL_ID, "UltraMax VPN", NotificationManager.IMPORTANCE_LOW)
            mgr.createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_ultramax)
            .setContentTitle("UltraMax Lite")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        mgr.notify(NOTIF_ID, buildNotification(text))
    }
}