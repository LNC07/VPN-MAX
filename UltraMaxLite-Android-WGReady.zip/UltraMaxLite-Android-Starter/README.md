# UltraMax Lite — Android Starter (VPN via VpnService + WireGuard integration points)

This is a **minimal Android starter** for your UltraMax Lite VPN app. It includes:
- Kotlin + Jetpack Compose UI (Connect/Disconnect)
- `VpnService` foreground service with notification
- Retrofit client placeholder to call your **Provisioning API** (`/api/peer`)
- Clear TODOs where you will integrate the **WireGuard userspace library**

> ⚠️ This starter does **not** implement the actual WireGuard tunnel yet. It sets up the TUN interface and foreground service, so you can plug in the WireGuard library and config application next.

## How to use

1. Open the project in **Android Studio (Giraffe or newer)**.
2. Update `app/src/main/AndroidManifest.xml` if needed.
3. Set your API base URL in `ApiClient.kt`.
4. Implement key generation (Curve25519) on-device, send `client_pubkey` to your API, and receive peer config.
5. **Integrate WireGuard**:
   - Option A: Embed the official `wireguard-android` userspace library as a module/aar.
   - Option B: Use `wireguard-go` userspace + JNI (more advanced).
6. Apply the received config to the WireGuard engine and attach to the file descriptor from `VpnService.Builder().establish()`.

## Package Structure

```
app/
  src/main/java/com/ultramaxlite/vpn/
    MainActivity.kt        # Compose UI
    UltraMaxApp.kt         # Application
    net/
      ApiClient.kt
      ProvisionApi.kt
    vpn/
      UltraMaxVpnService.kt  # Foreground VPN service (TODO: WireGuard integration)
  src/main/res/
    drawable/ic_ultramax.xml # App icon placeholder
    values/themes.xml
  AndroidManifest.xml
```

## Play Store Prep (later)
- Set **Data safety** form (no PII, crash-only analytics if used)
- Add **Privacy Policy** link (hosted)
- Use **Always-on VPN** + "Block connections without VPN" for kill-switch experience
- Test on Android 8–15, IPv6, DNS leak tests

## FastAPI Provisioning (server-side)
Pair this app with the provisioning API you created earlier to allocate IPs and return WG server info. Then apply WG config in the service.

---

**UltraMax Lite — Fast. Light. Private.**


## NEW: Keypair + Provisioning wired up
- App now **generates X25519 keypair** (Android API28+ native, fallback to BouncyCastle).
- Calls `/api/peer` with `client_pubkey` and stores returned fields.
- Builds a standard **wg-quick-style config** and saves it to app storage.
- Establishes the **TUN** interface.
- **Next step:** add the WireGuard engine (AAR/module) and apply the config to actually route traffic.

### Integrating the WireGuard Engine (drop-in)
1. Add the WireGuard userspace module to the project (official `wireguard-android` tunnel module).
2. Convert the saved config text to the engine's config model (Interface + Peer).
3. Bind the engine to the `ParcelFileDescriptor` returned by `builder.establish()` and start the tunnel.
